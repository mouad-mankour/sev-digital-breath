<?php
/**
 * Main template file for SEV Digital Breath React Theme
 */
get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>
